import sympy

# Define a symbolic variable
n = sympy.symbols('n')

# Define the factorial function symbolically
factorial_expr = sympy.factorial(n)

# Prompt the user for input
try:
    num = int(input("Enter a non-negative integer: "))
    if num < 0:
        raise ValueError("Input must be a non-negative integer")
except ValueError as e:
    print(f"Error: {e}")
else:
    # Calculate the factorial symbolically
    result = sympy.factorial(num)

    # Print the result
    print(f"{num}! = {result}")
